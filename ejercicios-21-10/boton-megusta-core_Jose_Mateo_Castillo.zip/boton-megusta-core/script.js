let megusta = 0;
function megusta1() {
    megusta++;
    document.getElementById("like1").innerText = megusta + " like(s)";
}

let megusta_1 = 0;
function megusta2() {
    megusta_1++;
    document.getElementById("like2").innerText = megusta_1 + " like(s)";
}

let megusta_2 = 0;
function megusta3() {
    megusta_2++;
    document.getElementById("like3").innerText = megusta_2 + " like(s)";
}

